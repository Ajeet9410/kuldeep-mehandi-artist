# Kuldeep Mehandi Artist website

A responsive static website for GitHub Pages.

## Before publishing
1. Confirm the phone/WhatsApp number in `index.html`. It currently uses the publicly shown number `086520 43398` (`+918652043398`).
2. Confirm the address and the business services are accurate.
3. Update the opening hours if you decide to add them.
4. Replace gallery images only with photos you have permission to use.

## Publish with GitHub Pages
1. Create a GitHub repository, for example `kuldeep-mehandi-artist`.
2. Upload `index.html`, `style.css`, and the `assets` folder to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select **main** and **/(root)**, then Save.
5. Wait for the deployment to finish. GitHub will show your website URL in Settings → Pages.

This is a static website and does not need a backend or database.
